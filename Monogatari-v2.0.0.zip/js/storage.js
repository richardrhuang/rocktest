/* global monogatari */

// Persistent Storage Variable
monogatari.storage ({
	player: {
		name: ''
	}
});